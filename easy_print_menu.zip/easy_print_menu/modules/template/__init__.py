""" some templates """
from .base_class import ModuleBase, UiModuleBase
